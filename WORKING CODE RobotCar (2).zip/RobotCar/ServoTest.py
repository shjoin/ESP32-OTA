# Import the Pin and PWM classes from the machine module
from machine import Pin, PWM   
# Import the time module
import time

servo_right = 54  
servo_centre = 90 #/90
servo_left = 126  #
servo_delay = 500 #ms

sarvo_pin='D10'  # GPIO21/D10
self.pwm = PWM(Pin(sarvo_pin))
self.pwm.freq(in_freqNo)
self.pwm.duty(servo_right)
print('Servo angle is Center')
'''
# Create a PWM object named 'servo' on pin 5 configured as an output
servo = PWM(Pin(9, mode=Pin.OUT))    
# Set the frequency of the PWM signal to 50Hz
servo.freq(50)                      
servo.duty(26)

# Start an infinite loop
while True:    
    # Set the duty cycle of the PWM signal to 26 (position 1 of the servo)
    servo.duty(26)  
    # Pause the program for 1 second  
    time.sleep(1)     
    # Set the duty cycle of the PWM signal to 123 (position 2 of the servo)
    servo.duty(123)  
    # Pause the program for 1 second 
    time.sleep(1)
'''    