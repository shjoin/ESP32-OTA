#!/usr/bin/python
# -*- coding: utf-8 -*-
from machine import Pin, PWM, ADC, time_pulse_us
from time import sleep, sleep_us, sleep_ms
from hc_sr04 import HCSR04


# import socket

class RobotCar:

    def __init__(
        self,
        enable_pins,
        motor_pins,        
        In_MEDIUM_POWER_LEVEL,
        in_trigger_pin,
        in_echo_pin,
        in_echo_timeout_us,
        in_sarvo_pin,
        in_servo_right,
        in_servo_centre,
        in_servo_left,
        in_servo_delay,
        in_freqNo,
        in_MAX_POWER_LEVEL,
        in_MIN_POWER_LEVEL        
        ):        
        print ('this is Class AutoRobotCar ')
        self.right_motor_enable_pin = PWM(Pin(enable_pins[0]),freq=2000)
        self.left_motor_enable_pin = PWM(Pin(enable_pins[1]), freq=2000)
        self.right_motor_control_1 = Pin(motor_pins[0], Pin.OUT)
        self.right_motor_control_2 = Pin(motor_pins[1], Pin.OUT)
        self.left_motor_control_1 = Pin(motor_pins[2], Pin.OUT)
        self.left_motor_control_2 = Pin(motor_pins[3], Pin.OUT)
        self.mid_speed = In_MEDIUM_POWER_LEVEL
        self.max_speed = in_MAX_POWER_LEVEL
        self.min_speed = in_MIN_POWER_LEVEL
        self.in_servo_delay = in_servo_delay
        self.in_trigger_pin = in_trigger_pin
        self.in_echo_pin = in_echo_pin
        self.in_echo_timeout_us = in_echo_timeout_us
        self.in_sarvo_pin = in_sarvo_pin
        self.in_servo_right = in_servo_right
        self.in_servo_centre = in_servo_centre
        self.in_servo_left = in_servo_left
        self.in_servo_delay = in_servo_delay
        self.in_freqNo = in_freqNo
        self.sensor = HCSR04(in_trigger_pin, in_echo_pin, in_echo_timeout_us)
        self.pwm = PWM(Pin(in_sarvo_pin))
        self.pwm.freq(in_freqNo)
        self.distance=30

        # self.ir_pin_left = Pin(in_IR_Sensor_left, Pin.IN)
        # self.ir_pin_right = Pin(in_IR_Sensor_right, Pin.IN)
        # self.counter =0

    def stop(self, t=0):
        print ('Car stopping')
        self.right_motor_enable_pin.duty_u16(0)
        self.left_motor_enable_pin.duty_u16(0)
        self.right_motor_control_1.value(0)
        self.right_motor_control_2.value(0)
        self.left_motor_control_1.value(0)
        self.left_motor_control_2.value(0)
        if t > 0:
            sleep_ms(t)    
            
    def set_speed(self, new_speed):
        self.speed = new_speed

    def cleanUp(self):
        print ('Cleaning up pins')
        self.right_motor_enable_pin.deinit()
        self.left_motor_enable_pin.deinit()

    def SarvoMotor(self, in_servo_duty):
        self.pwm.duty(in_servo_duty)

        # sleep(1)

    def forward_DistanceCheck(self):
        self.SarvoMotor(self.in_servo_centre)
        sleep_ms(self.in_servo_delay)
        distance = self.sensor.distance_cm()
        return round(distance, 2)

    def right_DistanceCheck(self):
        self.SarvoMotor(self.in_servo_right)
        sleep_ms(self.in_servo_delay)
        distance = self.sensor.distance_cm()
        return round(distance, 2)

    def left_DistanceCheck(self):
        self.SarvoMotor(self.in_servo_left)
        sleep_ms(self.in_servo_delay)
        distance = self.sensor.distance_cm()
        return round(distance, 2)

    def test(self):
        self.pwm.duty(self.in_servo_left)
        sleep_ms(self.in_servo_delay)
        self.pwm.duty(self.in_servo_centre)
        sleep_ms(self.in_servo_delay)
        distance = self.sensor.distance_cm()
        print ('Distnace', round(distance, 2))

    def Check_side(self):
        rightDistance_cm = self.right_DistanceCheck()
        sleep_ms(500)
        leftDistance_cm = self.left_DistanceCheck()
        sleep_ms(500)
        move=''
        if rightDistance_cm > leftDistance_cm and rightDistance_cm >= self.distance:
            move = 'Right'
            #self.SarvoMotor(self.in_servo_centre)  # Servo focus to center
        elif rightDistance_cm < leftDistance_cm and leftDistance_cm >= self.distance:
            move = 'Left'
            #self.SarvoMotor(self.in_servo_centre)  # Servo focus to center
        else:
            move = 'Reverse'
            #self.SarvoMotor(self.in_servo_centre)  # Servo focus to center
        return move
    
    def forward(self, t=0):
        print ('Move forward')
        self.right_motor_enable_pin.duty_u16(self.mid_speed)
        self.left_motor_enable_pin.duty_u16(self.mid_speed)
        self.right_motor_control_1.value(1)
        self.right_motor_control_2.value(0)
        self.left_motor_control_1.value(1)
        self.left_motor_control_2.value(0)
        if t > 0:
           sleep_ms(t)            

    def reverse(self, t=0):        
        print ('Move reverse')
        self.right_motor_enable_pin.duty_u16(self.max_speed)
        self.left_motor_enable_pin.duty_u16(self.max_speed)
        self.right_motor_control_1.value(0)
        self.right_motor_control_2.value(1)
        self.left_motor_control_1.value(0)
        self.left_motor_control_2.value(1)
        if t > 0:
            sleep_ms(t)

    def turnLeftold(self, t=0):
        print ('Turning Left')
        self.right_motor_enable_pin.duty_u16(self.mid_speed) #ENA
        self.left_motor_enable_pin.duty_u16(self.mid_speed) #ENB
        self.right_motor_control_1.value(1) #speed Antoclock wise (forward) IN1
        self.right_motor_control_2.value(0)  #IN2 Clockwise ( reverse)
        self.left_motor_control_1.value(0)  #speed Antoclock wise (forward) IN3
        self.left_motor_control_2.value(0) #IN4 Clockwise ( reverse)        
        '''
        #Second approach NOT working 
        self.right_motor_control_1.value(0) #speed Antoclock wise (forward) IN1
        self.right_motor_control_2.value(1)  #IN2 Clockwise ( reverse)
        self.left_motor_control_1.value(0)  #speed Antoclock wise (forward) IN3
        self.left_motor_control_2.value(1) #IN4 Clockwise ( reverse)
       '''        
        if t > 0:
            sleep_ms(t)
            
    def turnLeft(self, t=0):
        print ('Turning Left')        
        self.right_motor_enable_pin.duty_u16(self.max_speed) #ENA
        self.left_motor_enable_pin.duty_u16(self.max_speed) #ENB
        '''
        self.right_motor_control_1.value(1) #speed Antoclock wise (forward) IN1
        self.right_motor_control_2.value(0)  #IN2 Clockwise ( reverse)
        self.left_motor_control_1.value(0)  #speed Antoclock wise (forward) IN3
        self.left_motor_control_2.value(0) #IN4 Clockwise ( reverse)        
        '''
        #Second approach
        self.right_motor_control_1.value(1) #speed Antoclock wise (forward) IN1
        self.right_motor_control_2.value(0)  #IN2 Clockwise ( reverse)        
        self.left_motor_control_1.value(0)  #speed Antoclock wise (forward) IN3
        self.left_motor_control_2.value(1) #IN4 Clockwise ( reverse)        
        sleep_ms(450)        
        self.right_motor_control_1.value(1) #speed Antoclock wise (forward) IN1
        self.right_motor_control_2.value(0)  #IN2 Clockwise ( reverse)        
        self.left_motor_control_1.value(1)  #speed Antoclock wise (forward) IN3
        self.left_motor_control_2.value(0) #IN4 Clockwise ( reverse)
        if t > 0:
            sleep_ms(t)
            
    def turnRightold(self, t=0):
        print ('Turning Right')
        self.right_motor_enable_pin.duty_u16(self.mid_speed)
        self.left_motor_enable_pin.duty_u16(self.mid_speed)        
        self.right_motor_control_1.value(0)
        self.right_motor_control_2.value(0)
        self.left_motor_control_1.value(1)
        self.left_motor_control_2.value(0)        
        '''
        self.right_motor_control_1.value(1)
        self.right_motor_control_2.value(0)
        self.left_motor_control_1.value(1)
        self.left_motor_control_2.value(0)
        '''
        if t > 0:
            sleep_ms(t)
            
    def turnRight(self, t=0):
        print ('Turning Right')
        self.right_motor_enable_pin.duty_u16(self.max_speed)
        self.left_motor_enable_pin.duty_u16(self.max_speed)
        
        self.right_motor_control_1.value(0) #speed Antoclock wise (forward) IN1
        self.right_motor_control_2.value(1)  #IN2 Clockwise ( reverse)        
        self.left_motor_control_1.value(1)  #speed Antoclock wise (forward) IN3
        self.left_motor_control_2.value(0) #IN4 Clockwise ( reverse)
        
        sleep_ms(450)
        
        self.right_motor_control_1.value(0) #speed Antoclock wise (forward) IN1
        self.right_motor_control_2.value(1)  #IN2 Clockwise ( reverse)        
        self.left_motor_control_1.value(1)  #speed Antoclock wise (forward) IN3
        self.left_motor_control_2.value(0) #IN4 Clockwise ( reverse)
        
        '''
        self.right_motor_control_1.value(1)
        self.right_motor_control_2.value(0)
        self.left_motor_control_1.value(1)
        self.left_motor_control_2.value(0)
        '''
        if t > 0:
            sleep_ms(t)
            
    def autoDrive(self):
        centerDistance_cm = self.forward_DistanceCheck()
        if centerDistance_cm < self.distance:
            self.stop(500)
            #sleep_ms(500)
            self.reverse(200)
            self.stop(300)
            move = self.Check_side()            
            if move == 'Right':
                self.turnRight(100)
                self.stop(300)
            elif move == 'Left':
                self.turnLeft(100)
                self.stop(300)
            elif move == 'Reverse':
                self.reverse(200)
                self.stop(300)
            #else:
                #self.forward()
        else:
            self.forward()
            print ('Caling function self.forward()')

    '''    
    def linefollowDrive(self):
        ir_data_lft=0
        ir_data_rght=0
        ir_data_lft =  self.ir_pin_left.value() # Read data from the IR sensor
        ir_data_rght = self.ir_pin_right.value()
        #self.counter = self.counter+1
        #print('counter',self.counter)
        print(f"irLeft : {ir_data_lft}, irright: {ir_data_rght}")
        if ir_data_lft==0 and ir_data_rght ==0:            
            self.forward(200)
            print('forward')
            #sleep_ms(500)
        elif ir_data_lft==0 and ir_data_rght ==1:
            self.turnRight(200)
            print('right')
            #sleep_ms(500)
        elif ir_data_lft==1 and ir_data_rght ==0:    
            self.turnLeft(200)
            print('left')
            #sleep_ms(500)
        elif ir_data_lft==1 and ir_data_rght ==1:    
            self.stop(100)
            print('stop')
            #sleep_ms(500)
       '''     
        
             


