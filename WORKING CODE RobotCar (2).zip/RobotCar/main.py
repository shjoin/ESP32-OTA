from AutoRobotcar_linefollow import RobotCar
from time import sleep, sleep_us, sleep_ms
from machine import Pin, PWM, ADC, time_pulse_us,UART
from hc_sr04 import HCSR04
#from ir_tx import NEC
#from lib.ir_rx.ir_rx import NEC_16
#import BLE

print("============this is MAIN.py================")


# Wifi Robot Car Configuration
MAX_POWER_LEVEL = 65535		# 100%
MEDIUM_POWER_LEVEL = 49151  # 75%
MIN_POWER_LEVEL = 32767		# 50%


enable_pins = ['D9', 'D4']
motor_pins = ['D8', 'D7', 'D6', 'D5']

#enable_pins_2 = ['A1', 'A6']
#motor_pins_2 = ['A2', 'A3', 'A4', 'A5']

#enable_pins_2 = [2, 13]
#motor_pins_2 = [3,4,11,12]


trigger_pin='D12'
echo_pin='D11'
echo_timeout_us=100000
#IR_Sensor_left ='D03' #/ GPIO6
#IR_Sensor_right ='D02'#/GPIO5

#IR_Sensor_left =6 #/ GPIO6
#IR_Sensor_right =5 #/GPIO5

#ir = NEC_16(Pin(48, Pin.IN), callback) #D13/GPIO48

#LED_pin ='D2' # GPIO5/D2
#LED_pin = 2 # not working 
#LED_pin = 5 # working  # GPIO5/D2
sarvo_pin='D10'  # GPIO21/D10
#sarvo_pin=3  # GPIO3 /A2 /D19
freqNo=50
servo_right = 54  
servo_centre = 90 #/90
servo_left = 126  #
servo_delay = 300 #ms

robot_car = RobotCar(enable_pins, motor_pins, MEDIUM_POWER_LEVEL,trigger_pin,echo_pin,echo_timeout_us,sarvo_pin,servo_right,servo_centre,servo_left,servo_delay,freqNo,MAX_POWER_LEVEL,MIN_POWER_LEVEL)
#if IR.decodedIRData.decodedRawData == 0xBF40FF00   #// remote OK for Turn ON   
while True:
  robot_car.autoDrive()
  #robot_car.linefollowDrive()
            
    


#led=Pin(LED_pin,Pin.OUT) #create LED object from pin2,Set Pin2 to output
#robot_car = RobotCar(enable_pins, motor_pins, MEDIUM_POWER_LEVEL,trigger_pin,echo_pin,echo_timeout_us,sarvo_pin,servo_right,servo_centre,servo_left,servo_delay,freqNo,MAX_POWER_LEVEL,MIN_POWER_LEVEL)
#UART = UART(0, baudrate=115200)

'''
#pwm = PWM(Pin(21, mode=Pin.OUT))
#pwm = PWM(Pin('D10', mode=Pin.OUT))
pwm = PWM(Pin(10, mode=Pin.OUT))   # not working 
pwm.freq(50)
pwm.duty(26)
sleep_ms(servo_delay)
print('servo_right ')
pwm.duty(123)
sleep_ms(servo_delay)
pwm.duty(90)

'''


#pwm.duty(servo_right)

#sensor = HCSR04(trigger_pin, echo_pin,echo_timeout_us)
#distance = sensor.distance_cm()
#print('distance ', distance)
#BLE.demo()


'''
counter=0
while True:  
  led.value(1)
  counter=counter+1  
  print('counter  ',counter)
  print('light on ')    
  #pwm.duty(26)
  sleep_ms(servo_delay)
  print('servo_right ')
  #pwm.duty(123)
  led.value(0)
  #led.off()
  print('servo_center ')
  print('light off ')
  #distance = sensor.distance_cm()
  #print('distance ', distance)
  #robot_car.autoDrive()

'''  
'''
robot_car.SarvoMotor(servo_right)
sleep_ms(servo_delay)
robot_car.SarvoMotor(servo_centre)
sleep_ms(servo_delay)
robot_car.SarvoMotor(servo_left)
'''
'''
pwm = PWM(Pin(sarvo_pin))
pwm.freq(freqNo)        
pwm.duty(servo_right)
sleep_ms(servo_delay)
pwm.duty(servo_centre)
sleep_ms(servo_delay)
pwm.duty(servo_left)
        
#dist1=robot_car.forward_DistanceCheck()
#print('forward',dist1)

'''
'''
sensor = HCSR04(trigger_pin=42, echo_pin=11,echo_timeout_us=1000000)
pwm = PWM(Pin(sarvo_pin))
pwm.freq(freqNo)

while True:
    sleep_ms(servo_delay)
    centerDistance_cm = sensor.distance_cm()        
    print('forward-center ', centerDistance_cm)
    sleep_ms(servo_delay)
 '''
'''
sensor = HCSR04(trigger_pin=42, echo_pin=11)
pwm = PWM(Pin(sarvo_pin))
pwm.freq(freqNo)
'''

'''
pwm.duty(servo_centre) # Servo focus to center
sleep_ms(servo_delay) 
pwm.duty(servo_left) # Servo focus to center
sleep_ms(servo_delay) 
pwm.duty(servo_centre) # Servo focus to center
sleep_ms(servo_delay) 
pwm.duty(servo_right) # Servo focus to center
sleep_ms(servo_delay) 
pwm.duty(servo_centre) # Servo focus to center
'''

'''
while True:
    
    pwm.duty(servo_centre) # Servo focus to center
    sleep_ms(servo_delay)
    centerDistance_cm = sensor.distance_cm()        
    print('forward ', centerDistance_cm)    #sleep_ms(servo_delay)    
    pwm.duty(servo_right)
    sleep_ms(servo_delay)            
    rightDistance_cm = sensor.distance_cm()
    print('rightDistance_cm ',rightDistance_cm)
    sleep_ms(servo_delay)                 
    pwm.duty(servo_centre)E # Servo focus to center
    centerDistance_cm = sensor.distance_cm()        
    print('forward-2 ', centerDistance_cm)    
    sleep_ms(servo_delay)                 
    pwm.duty(servo_left)
    sleep_ms(servo_delay)            
    leftDistance_cm = sensor.distance_cm()
    print('leftDistance_cm ',leftDistance_cm)
    sleep_ms(servo_delay) 
'''
   


